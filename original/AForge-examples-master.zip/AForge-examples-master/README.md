# AForge-examples
How to connect to a USB camera or IP camera with AForge framework. 
Read the original artiche at http://www.mesta-automation.com/getting-started-with-computer-vision-in-c-sharp/
